/*----------------------------------------------------------------------*/
/* Foolproof FatFs sample project for AVR              (C)ChaN, 2013    */
/* Adapted for Zedboard                                (C)Edh,  2014    */
/*----------------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include "platform.h"
#include "xparameters.h"  // Zynq parameters
#include "xgpiops.h"      // Zynq GPIO operations
  
#include "ff.h"		/* Declarations of FatFs API */

FATFS FatFs;		/* FatFs work area needed for each volume */
FIL Fil;			/* File object needed for each open file */

XGpioPs Gpio;

int main (void)
{
	UINT bw;		// bytes written
	int retval;		// return value for Gpio functions

	init_platform();

	// Lookup GPIO config table
	XGpioPs_Config * ConfigPtr = XGpioPs_LookupConfig(XPAR_PS7_GPIO_0_DEVICE_ID);

	// Initialize GPIO
    if ( (retval = XGpioPs_CfgInitialize(&Gpio, ConfigPtr, ConfigPtr->BaseAddr)) != XST_SUCCESS) {
   		printf("Error initalizing GPIO fails\n"); return retval;}
	if ( (retval = XGpioPs_SelfTest(&Gpio)) != XST_SUCCESS) {
		printf("GPIO Self test fails\n"); return 1; }

	/*
	 *  Write files to SDC using FatFs SPI protocol
	 */

	f_mount(&FatFs, "", 0);		/* Give a work area to the default drive */
	if (f_open(&Fil, "newfile.txt", FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {	/* Create a file */
		f_write(&Fil, "It works!\r\n", 11, &bw);	/* Write data to the file */
		f_close(&Fil);								/* Close the file */
	}

	// Check result
	if(bw == 11) // how many bytes written?
		printf("File written successfully\n");
	else
		printf("File write error\n");
	exit(1);

}



/*---------------------------------------------------------*/
/* User Provided RTC Function called by FatFs module       */

DWORD get_fattime ()
{
#define FILDAT "20140514" 	// set time stamp in the absence of gettimeofday()
#define FILTIM "123500"		// for bare metal BSP

	int Y, M, D, hh, mm, ss;
	char token[20], *endptr;

	endptr=stpncpy(token,FILDAT,4);*endptr=0; 		Y = atoi(token);
	endptr=stpncpy(token,FILDAT+4,2);*endptr=0; 	M = atoi(token);
	endptr=stpncpy(token,FILDAT+6,2);*endptr=0; 	D = atoi(token);
	endptr=stpncpy(token,FILTIM,2);*endptr=0; 		hh = atoi(token);
	endptr=stpncpy(token,FILTIM+2,2);*endptr=0; 	mm = atoi(token);
	endptr=stpncpy(token,FILTIM+4,2);*endptr=0; 	ss = atoi(token);

	/* Returns current time packed into a DWORD variable */
	return	  ((DWORD)(Y - 1980) << 25)	/* Year 2013 */
			| ((DWORD)M << 21)				/* Month 7 */
			| ((DWORD)D << 16)				/* Mday 28 */
			| ((DWORD)hh << 11)				/* Hour 0 */
			| ((DWORD)mm << 5)				/* Min 0 */
			| ((DWORD)ss >> 1);				/* Sec 0 */
}

